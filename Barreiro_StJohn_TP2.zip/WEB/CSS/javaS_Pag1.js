var posicionInicial = -400; 
var posicionFinal = 800;
var movY = 15;

function moverImagen(img) {
    var currentY = parseInt(img.style.transform.replace('translateY(', '').replace('px)', '')) || 0; 
    currentY += movY;

    if (currentY >= posicionFinal) {
        currentY = posicionInicial; 
    }

    img.style.transform = 'translateY(' + currentY + 'px)'; 
}

function iniciarMovimiento() {
    var images = document.querySelectorAll('#derCards img, #leftCards img');
    setInterval(function() {
        images.forEach(function(img) {
            moverImagen(img); //Mover cada imagen
        });
    }, 100); //Ajusta el intervalo de tiempo según sea necesario
}

document.addEventListener('DOMContentLoaded', iniciarMovimiento);

//INICIA NUEVO SCRIPT//
const links = document.querySelectorAll('#links .centrado a');

function agrandarTexto(event) {
    event.target.style.transform = 'scale(2.5)';
}

function devolverTexto(event) {
    event.target.style.transform = 'scale(1.5)';
}

links.forEach(link => {
    link.addEventListener('mouseenter', agrandarTexto); 
    link.addEventListener('mouseleave', devolverTexto); 
});

//Cuestionario Script//
function formSent()
{
    var userResult;
    var emailResult;
    userResult=document.getElementById("user").value;
    emailResult=document.getElementById("mail").value;
    alert("Gracias "+userResult+" por visitar nuestro sitio web. Te contactaremos a este mail "+emailResult);
}
//Selector de Personajes Script//
function mostrarPersonajes() {
    $("#listaPersonajes").toggle();
}
function mostrarInfoPersonaje(personaje) {
    const imagenes = {
      arthur: "Fotos/Arthur.png",
      merlin: "Fotos/Merlin.png",
      lancelot: "Fotos/lancelot.png",
      mordred: "Fotos/Mordred.png",
      geriant: "Fotos/geriant.png",
      percival: "Fotos/percival.jpg"
    };

    const descripciones = {
      arthur: "Es el <u><b>líder de los caballeros y el rey</u></b>. Su <u><b>objetivo</u></b> es descubrir al traidor. <br> Arturo debe ser <u><b>defendido</u></b> a toda costa y tiene la <u><b>decisión final</u></b> sobre las votaciones de sus caballeros. <br> Si los <u><b>votos son iguales</u></b> para ejecutar a un miembro de la mesa Arturo podrá <u><b>decidir el SI o NO final</u></b>",
      merlin: "Es el <u><b>mago de los caballeros</u></b> y sirve a Arturo. Su objetivo es <u><b>descubrir al traidor</u></b> de la mesa. <br>Para ello Merlin puede cada 3 noches de reunión <u><b>revisar la carta del jugador</u></b> que quiera.",
      lancelot: "Es el caballero favorito y escudero de Arturo. Su objetivo es proteger a Arturo utilizando su <u><b>habilidad de escudo</u></b>.<br> Cada 2 noches de reunión podrá proteger con su <u><b>habilidad mágica de escudo</u></b> a alguien de la mesa. <br>Este también puede cometer el <u><b>error de proteger a los traidores</u></b>.",
      mordred: "El primero de los traidores.<br> El caballero traidor podrá <u><b>cada 1 noche de reunión eliminar al jugador</u></b> que quiera. <br>Tendrá el <u><b>voto de ORO sobre su compañero traidor</u></b> sino se ponen de acuerdo",
      geriant: "El segundo de los traidores.<br> El caballero podrá <u><b>cada 1 noche de reunión eliminar a jugador</u></b> que quiera.<br>Sin embargo debera <u><b>elijir el mismo</u></b> que su compañero Mordred.",
      percival: "Su <u><b>objetivo es salvar a Arturo</u></b> del traidor.<br> Para ello podrá conocer la <u><b>identidad de Arturo</u></b> al inicio del juego y siempre la verá. <br>Este puede usarlo a su favor pero <u><b>sí revela demasiado la identidad</u></b> de su Rey podrá hacerlo morir por los traidores."
    };

    const tablas = {
        arthur: "#tablaArthur",
        merlin: "#tablaMerlin",
        lancelot: "#tablaLancelot",
        mordred: "#tablaMordred",
        geriant: "#tablaGeriant",
        percival: "#tablaPercival"
    };
    $(".tabla").hide();

    if (imagenes[personaje] && descripciones[personaje]) {
        $("#personajeImagen").fadeOut(300, function() {
          $("#imagenPersonaje").attr("src", imagenes[personaje]);
          $("#descripcionPersonaje").html(descripciones[personaje]);
          $("#personajeImagen").fadeIn(300);
        });
        $(tablas[personaje]).fadeIn();
      } else {
        $("#personajeImagen").hide();
      }
    }

  $(document).ready(function() {
    $("#mostrarPersonajes").click(mostrarPersonajes);

    $("#listaPersonajes").change(function() {
      const personajeSeleccionado = $(this).val();
      mostrarInfoPersonaje(personajeSeleccionado);
    });
  });